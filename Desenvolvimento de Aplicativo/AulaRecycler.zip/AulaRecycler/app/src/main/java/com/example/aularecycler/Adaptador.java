package com.example.aularecycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.MyViewHolder> {
    Context context;
    ArrayList<Livro> lista;
    Adaptador.onItemClickListner listner;

    public Adaptador(Context context, ArrayList<Livro> lista, onItemClickListner listner) {
        this.context = context;
        this.lista = lista;
        this.listner = listner;
    }

    @NonNull
    @Override
    public Adaptador.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout, parent, false);
        return new Adaptador.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptador.MyViewHolder holder, int position) {
        Livro l = lista.get(position);
        holder.titulo.setText(l.titulo);
        holder.autor.setText(l.autor);
        holder.genero.setText(l.genero);
        holder.classificacao.setText(l.classificacao);
        holder.sinopse.setText(l.sinopse);
        holder.ISBN.setText(l.ISBN);
        holder.itemView.setOnClickListener(View ->{
            listner.onItemClick(l);
        });

    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public interface onItemClickListner {
        void onItemClick(Livro livro);

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView titulo, autor, genero, classificacao, sinopse, ISBN;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.tituloCard);
            autor = itemView.findViewById(R.id.autorCard);
            genero = itemView.findViewById(R.id.generoCard);
            classificacao = itemView.findViewById(R.id.classificacaoCard);
            sinopse = itemView.findViewById(R.id.sinopseCard);
            ISBN = itemView.findViewById(R.id.ISBNCard);
        }
    }


}
