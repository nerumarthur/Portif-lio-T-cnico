package com.example.aularecycler;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText tituloj, autorj, generoj, classificacaoj, sinopsej, ISBNj;
    AlertDialog.Builder alerta;
    ArrayList <Livro> Livros = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        tituloj = findViewById(R.id.campoTitulo);
        autorj = findViewById(R.id.campoAutor);
        generoj = findViewById(R.id.campoGenero);
        classificacaoj = findViewById(R.id.campoClass);
        sinopsej = findViewById(R.id.campoSino);
        ISBNj = findViewById(R.id.campoISBN);
        alerta = new AlertDialog.Builder(this);

    }
    public void cadastrar(View view){
       Livro l = new Livro();
       String mensagem = "Livro ";
       l.titulo = tituloj.getText().toString();
       l.autor = autorj.getText().toString();
       l.genero = generoj.getText().toString();
       l.classificacao = classificacaoj.getText().toString();
       l.sinopse = sinopsej.getText().toString();
       l.ISBN = ISBNj.getText().toString();
       Livros.add(l);
       mensagem += tituloj.getText().toString()+" Cadastrado Com Sucesso";
       alerta.setTitle("Cadastro");
       alerta.setMessage(mensagem);
       alerta.show();

    }
    public void exibir(View view){
        Intent i = new Intent(this,TelaBiblioteca.class);
        startActivity(i);
        TelaBiblioteca.biblioteca = this.Livros;


    }
    public void limpar(View view){
        tituloj.setText("");
        autorj.setText("");
        generoj.setText("");
        classificacaoj.setText("");
        sinopsej.setText("");
        ISBNj.setText("");


    }


}