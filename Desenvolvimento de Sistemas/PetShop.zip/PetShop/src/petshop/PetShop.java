package petshop;

public class PetShop {

    public static void main(String[] args) {
       Cadastrar c = new Cadastrar();
       c.setVisible(true);
    }
    
}
