package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        mt = findViewById(R.id.matriz);
        criarMatriz();
    }

    public void criarMatriz(){
        String matriz = "Matriz\n";
        int [][] numeros = {{9,8,7},{4,5,6},{3,1,2}};
        for(int linha = 0; linha<3; linha++){
            for(int coluna = 0; coluna <3; coluna++){
                matriz += numeros[linha][coluna]+" ";
            }
            matriz += "\n";
        }
        mt.setText(matriz);


    }
}