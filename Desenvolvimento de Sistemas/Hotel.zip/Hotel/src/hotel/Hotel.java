

package hotel;
import java.util.Scanner;
/**
 *
 * @author arthur_steinbach
 */
public class Hotel {

    public static void main(String[] args) {
       Scanner Sc = new Scanner(System.in);
            int D = Sc.nextInt();
            int A = Sc.nextInt();
            int N = Sc.nextInt();
            int dChegou = N; //Variavel dia que chegou
        if (dChegou > 15) dChegou = 15;
		int Diaria = D + (dChegou-1)*A; //Variavel do Valor da diaria 
		System.out.printf("%d\n",(31 - N + 1)*Diaria);
    }
    
}
