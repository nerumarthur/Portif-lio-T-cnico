package com.example.aularecycler;

public class Livro {
    String titulo, autor, genero, classificacao, sinopse, ISBN;

    public Livro(String titulo, String autor, String genero, String classificacao, String sinopse, String ISBN) {
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.classificacao = classificacao;
        this.sinopse = sinopse;
        this.ISBN = ISBN;
    }

    public Livro() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getSinopse() {
        return sinopse;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
}
