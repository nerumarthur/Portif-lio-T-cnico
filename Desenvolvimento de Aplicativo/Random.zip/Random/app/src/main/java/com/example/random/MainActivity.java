package com.example.random;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText dados,lados;
    TextView result;
    ImageView imgDado;
    int numDados,numLados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dados = findViewById(R.id.dados);
        lados = findViewById(R.id.lados);
        result = findViewById(R.id.Resultado);
        imgDado = findViewById(R.id.img);

    }


    public void play(View view){

            try {
                numDados = Integer.parseInt(dados.getText().toString());
                numLados = Integer.parseInt(lados.getText().toString());
            }
            catch (Exception e){
                numDados = 0;
                numLados = 0;
                Toast.makeText(this, "Falta Dados",Toast.LENGTH_LONG).show();

            }
        Random mauricio = new Random();
        /* int q = 0;
        String s = "Resultado:\n";
        while (q < numDados){
            q++;
            s += "Dado "+q+": "+(mauricio.nextInt(numLados)+1)+"\n";*/


        //}
       // result.setText(s);
        int gerado = mauricio.nextInt(numLados)+1;
        if(numLados == 4){
            if(gerado == 1){
                imgDado.setImageResource(R.drawable.d4tirou1);
            }
            else if(gerado == 2){

                imgDado.setImageResource(R.drawable.d4tirou2);
            }
            else if(gerado == 3){

                imgDado.setImageResource(R.drawable.d4tirou3);
            }
            else if(gerado == 4){

                imgDado.setImageResource(R.drawable.d4tirou4);
            }

        }
        else if (numLados == 6){
            if (gerado == 1){
                imgDado.setImageResource(R.drawable.d6tirou1);

            }
            else if (gerado == 2){
                imgDado.setImageResource(R.drawable.d6tirou2);


            }
            else if (gerado == 3){
                imgDado.setImageResource(R.drawable.d6tirou3);


            }
            else if (gerado == 4){
                imgDado.setImageResource(R.drawable.d6tirou4);


            }
            else if (gerado == 5){
                imgDado.setImageResource(R.drawable.d6tirou5);


            }
            else if (gerado == 6){
                imgDado.setImageResource(R.drawable.d6tirou6);


            }




        }


    }
}