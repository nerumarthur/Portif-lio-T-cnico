package petshop;

public class Animal {
    String nome;
    String raça;
    String sexo;
    String idade;
    String peso;

    public Animal(String nome, String raça, String sexo, String idade, String peso) {
        this.nome = nome;
        this.raça = raça;
        this.sexo = sexo;
        this.idade = idade;
        this.peso = peso;
    }

    Animal(String toString, String toString0, String toString1, String toString2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaça() {
        return raça;
    }

    public void setRaça(String raça) {
        this.raça = raça;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }
    
}
