package com.example.aularecycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaBiblioteca extends AppCompatActivity {
    static ArrayList<Livro> biblioteca;
    RecyclerView rv;
    Adaptador javackson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_biblioteca);
        getSupportActionBar().hide();
        rv = findViewById(R.id.lista);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        javackson = new Adaptador(this, biblioteca, new Adaptador.onItemClickListner() {
            @Override
            public void onItemClick(Livro livro) {

            }
        });
        rv.setAdapter(javackson);
        javackson.notifyDataSetChanged();
    }




}